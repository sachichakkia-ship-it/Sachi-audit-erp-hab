<?php
/**
 * Executive Main Dashboard (Top 5 KPI Cards + 9 Branch Cards)
 * File: index.php
 */
declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';

$pageTitle = 'Executive Dashboard | Stock Audit Pro';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// 1. TOP 5 KPI METRICS
$totalTargetItems = (int)$pdo->query("SELECT COUNT(*) FROM target_items")->fetchColumn();
$totalAuditedItems = (int)$pdo->query("SELECT COUNT(*) FROM view_deduplicated_audits")->fetchColumn();
$targetAuditedItems = (int)$pdo->query("SELECT COUNT(*) FROM view_deduplicated_audits WHERE audit_classification = 'TARGET_AUDITED'")->fetchColumn();
$extraAuditedItems = (int)$pdo->query("SELECT COUNT(*) FROM view_deduplicated_audits WHERE audit_classification = 'EXTRA_AUDITED'")->fetchColumn();
$netAmountDifference = (float)$pdo->query("SELECT COALESCE(SUM(net_total), 0) FROM adjustments")->fetchColumn();
$auditProgressPercent = $totalTargetItems > 0 ? round(($targetAuditedItems / $totalTargetItems) * 100, 1) : 0;

// 2. 9 BRANCH CARDS
$branchCodes = ['EME', 'BT', 'AB', 'KB', 'KT', 'GT', 'WT', 'MT', 'WH'];
$branchCards = [];

foreach ($branchCodes as $code) {
    $bStmt = $pdo->prepare("SELECT name FROM branches WHERE code = ? LIMIT 1");
    $bStmt->execute([$code]);
    $branchName = $bStmt->fetchColumn() ?: $code . ' Branch';

    $audStmt = $pdo->prepare("
        SELECT a.name 
        FROM auditor_transfers t
        INNER JOIN auditors a ON t.auditor_id = a.id
        WHERE t.branch_code = ? AND t.end_date IS NULL
        ORDER BY t.start_date DESC LIMIT 1
    ");
    $audStmt->execute([$code]);
    $currentAuditor = $audStmt->fetchColumn() ?: 'No Auditor Assigned';

    $bTargetStmt = $pdo->prepare("SELECT COUNT(*) FROM target_items WHERE branch_code = ?");
    $bTargetStmt->execute([$code]);
    $bTargetItems = (int)$bTargetStmt->fetchColumn();

    $bAuditedStmt = $pdo->prepare("SELECT COUNT(*) FROM view_deduplicated_audits WHERE branch_code = ?");
    $bAuditedStmt->execute([$code]);
    $bTotalAudited = (int)$bAuditedStmt->fetchColumn();

    $bTgtAudStmt = $pdo->prepare("SELECT COUNT(*) FROM view_deduplicated_audits WHERE branch_code = ? AND audit_classification = 'TARGET_AUDITED'");
    $bTgtAudStmt->execute([$code]);
    $bTargetAudited = (int)$bTgtAudStmt->fetchColumn();

    $bExtraStmt = $pdo->prepare("SELECT COUNT(*) FROM view_deduplicated_audits WHERE branch_code = ? AND audit_classification = 'EXTRA_AUDITED'");
    $bExtraStmt->execute([$code]);
    $bExtraAudited = (int)$bExtraStmt->fetchColumn();

    $bNetStmt = $pdo->prepare("SELECT COALESCE(SUM(net_total), 0) FROM adjustments WHERE branch_code = ?");
    $bNetStmt->execute([$code]);
    $bNetTotal = (float)$bNetStmt->fetchColumn();

    $bPendingItems = max(0, $bTargetItems - $bTargetAudited);
    $bProgress = $bTargetItems > 0 ? round(($bTargetAudited / $bTargetItems) * 100, 1) : 0;

    $branchCards[] = [
        'code'            => $code,
        'name'            => $branchName,
        'auditor'         => $currentAuditor,
        'target_items'    => $bTargetItems,
        'total_audited'   => $bTotalAudited,
        'target_audited'  => $bTargetAudited,
        'extra_audited'   => $bExtraAudited,
        'pending_items'   => $bPendingItems,
        'net_total'       => $bNetTotal,
        'progress'        => $bProgress
    ];
}
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">Executive Audit Overview</h3>
        <p class="text-muted m-0">Consolidated stock audit KPIs, deduplicated items, and branch-level variances.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="import.php" class="btn btn-outline-primary fw-semibold">
            <i class="bi bi-cloud-arrow-up me-1"></i> Upload Sheet
        </a>
        <a href="auditors.php" class="btn btn-primary fw-semibold">
            <i class="bi bi-people me-1"></i> Auditor Transfers
        </a>
    </div>
</div>

<!-- 1. Top 5 KPI Cards -->
<div class="row g-3 mb-4">
    <div class="col-xl col-md-4 col-sm-6">
        <div class="card card-custom p-3 border-start border-primary border-4 shadow-sm h-100">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="text-muted small fw-bold text-uppercase">Total Target Items</span>
                <i class="bi bi-bullseye fs-4 text-primary"></i>
            </div>
            <h3 class="fw-bold text-dark mb-1"><?= number_format($totalTargetItems) ?></h3>
            <span class="text-muted small">All 9 Branches combined</span>
        </div>
    </div>

    <div class="col-xl col-md-4 col-sm-6">
        <div class="card card-custom p-3 border-start border-info border-4 shadow-sm h-100">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="text-muted small fw-bold text-uppercase">Total Audited Items</span>
                <i class="bi bi-qr-code-scan fs-4 text-info"></i>
            </div>
            <h3 class="fw-bold text-dark mb-1"><?= number_format($totalAuditedItems) ?></h3>
            <span class="text-info small fw-bold"><i class="bi bi-layers me-1"></i>Deduplicated Unique Scans</span>
        </div>
    </div>

    <div class="col-xl col-md-4 col-sm-6">
        <div class="card card-custom p-3 border-start border-success border-4 shadow-sm h-100">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="text-muted small fw-bold text-uppercase">Target Items Audited</span>
                <i class="bi bi-check2-circle fs-4 text-success"></i>
            </div>
            <h3 class="fw-bold text-success mb-1"><?= number_format($targetAuditedItems) ?></h3>
            <span class="text-muted small">Progress: <strong><?= $auditProgressPercent ?>%</strong> matched</span>
        </div>
    </div>

    <div class="col-xl col-md-6 col-sm-6">
        <div class="card card-custom p-3 border-start border-warning border-4 shadow-sm h-100">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="text-muted small fw-bold text-uppercase">Extra Items Audited</span>
                <i class="bi bi-exclamation-triangle fs-4 text-warning"></i>
            </div>
            <h3 class="fw-bold text-dark mb-1"><?= number_format($extraAuditedItems) ?></h3>
            <span class="text-muted small">Scanned outside target list</span>
        </div>
    </div>

    <div class="col-xl col-md-6 col-sm-12">
        <div class="card card-custom p-3 border-start <?= $netAmountDifference >= 0 ? 'border-success' : 'border-danger' ?> border-4 shadow-sm h-100">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="text-muted small fw-bold text-uppercase">Net Amount Diff (PKR)</span>
                <i class="bi bi-cash-stack fs-4 <?= $netAmountDifference >= 0 ? 'text-success' : 'text-danger' ?>"></i>
            </div>
            <h3 class="fw-bold <?= $netAmountDifference >= 0 ? 'text-success' : 'text-danger' ?> mb-1">
                PKR <?= number_format($netAmountDifference, 2) ?>
            </h3>
            <span class="small <?= $netAmountDifference >= 0 ? 'text-success' : 'text-danger' ?>">
                <?= $netAmountDifference >= 0 ? '<i class="bi bi-arrow-up-right"></i> Net Excess / Surplus' : '<i class="bi bi-arrow-down-right"></i> Net Shortage Impact' ?>
            </span>
        </div>
    </div>
</div>

<!-- Section Heading -->
<div class="d-flex justify-content-between align-items-center mb-3 mt-4">
    <h5 class="fw-bold text-dark m-0"><i class="bi bi-shop me-2 text-primary"></i> 9 Individual Branch Status</h5>
    <small class="text-muted">Real-time breakdown of all operational branches</small>
</div>

<!-- 2. 9 Branch Cards -->
<div class="row g-3">
    <?php foreach ($branchCards as $b): ?>
        <div class="col-xl-4 col-md-6">
            <div class="card card-custom shadow-sm h-100 p-3">
                <div class="d-flex justify-content-between align-items-start border-bottom pb-2 mb-3">
                    <div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-primary fs-6 fw-bold"><?= $b['code'] ?></span>
                            <h6 class="fw-bold text-dark m-0"><?= htmlspecialchars($b['name']) ?></h6>
                        </div>
                        <small class="text-muted d-block mt-1">
                            <i class="bi bi-person-circle text-secondary me-1"></i>
                            Auditor: <strong class="<?= $b['auditor'] !== 'No Auditor Assigned' ? 'text-dark' : 'text-danger' ?>"><?= htmlspecialchars($b['auditor']) ?></strong>
                        </small>
                    </div>
                    <span class="badge bg-light text-dark border"><?= $b['progress'] ?>% Done</span>
                </div>

                <div class="progress mb-3" style="height: 6px;">
                    <div class="progress-bar bg-success" role="progressbar" style="width: <?= min(100, $b['progress']) ?>%"></div>
                </div>

                <div class="row g-2 text-center mb-3">
                    <div class="col-4">
                        <div class="bg-light p-2 rounded">
                            <small class="text-muted d-block" style="font-size: 11px;">Target Items</small>
                            <span class="fw-bold text-dark"><?= number_format($b['target_items']) ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="bg-light p-2 rounded">
                            <small class="text-muted d-block" style="font-size: 11px;">Audited (Unique)</small>
                            <span class="fw-bold text-primary"><?= number_format($b['total_audited']) ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="bg-light p-2 rounded">
                            <small class="text-muted d-block" style="font-size: 11px;">Target Audited</small>
                            <span class="fw-bold text-success"><?= number_format($b['target_audited']) ?></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-light p-2 rounded">
                            <small class="text-muted d-block" style="font-size: 11px;">Extra Items Audited</small>
                            <span class="fw-bold text-warning"><?= number_format($b['extra_audited']) ?></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-light p-2 rounded">
                            <small class="text-muted d-block" style="font-size: 11px;">Pending Items</small>
                            <span class="fw-bold text-danger"><?= number_format($b['pending_items']) ?></span>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto">
                    <span class="text-muted small fw-semibold">Net Amount Diff:</span>
                    <span class="fw-bold <?= $b['net_total'] >= 0 ? 'text-success' : 'text-danger' ?>">
                        PKR <?= number_format($b['net_total'], 2) ?>
                    </span>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>