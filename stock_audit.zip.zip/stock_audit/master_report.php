<?php
/**
 * Option 5: Complete Master Working Report
 * File: master_report.php
 */
declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';

$pageTitle = 'Master Working Report | Stock Audit Pro';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Fetch Overall Master Stats for All 9 Branches
$branchCodes = ['EME', 'BT', 'AB', 'KB', 'KT', 'GT', 'WT', 'MT', 'WH'];

$masterData = [];
$totalAllTargets = 0;
$totalAllAudited = 0;
$totalAllTargetAudited = 0;
$totalAllExtraAudited = 0;
$totalAllPending = 0;
$totalAllFinancialVariance = 0.0;

foreach ($branchCodes as $code) {
    // 1. Branch Info
    $bStmt = $pdo->prepare("SELECT name FROM branches WHERE code = ? LIMIT 1");
    $bStmt->execute([$code]);
    $branchName = $bStmt->fetchColumn() ?: $code . ' Branch';

    // 2. Current Active Auditor
    $audStmt = $pdo->prepare("
        SELECT a.name, t.daily_target_items, t.target_days 
        FROM auditor_transfers t
        INNER JOIN auditors a ON t.auditor_id = a.id
        WHERE t.branch_code = ? AND t.end_date IS NULL
        ORDER BY t.start_date DESC LIMIT 1
    ");
    $audStmt->execute([$code]);
    $auditorInfo = $audStmt->fetch();

    $auditorName = $auditorInfo['name'] ?? 'Unassigned';
    $dailyTarget = (int)($auditorInfo['daily_target_items'] ?? 300);
    $targetDays  = (float)($auditorInfo['target_days'] ?? 0);

    // 3. Branch Total Target Items
    $bTargetStmt = $pdo->prepare("SELECT COUNT(*) FROM target_items WHERE branch_code = ?");
    $bTargetStmt->execute([$code]);
    $targetItemsCount = (int)$bTargetStmt->fetchColumn();

    // 4. Branch Deduplicated Audits
    $dedupStmt = $pdo->prepare("
        SELECT 
            COUNT(item_code) AS total_unique_audited,
            SUM(CASE WHEN audit_classification = 'TARGET_AUDITED' THEN 1 ELSE 0 END) AS target_audited,
            SUM(CASE WHEN audit_classification = 'EXTRA_AUDITED' THEN 1 ELSE 0 END) AS extra_audited,
            COALESCE(SUM(total_net_value), 0) AS branch_net_total
        FROM view_deduplicated_audits
        WHERE branch_code = ?
    ");
    $dedupStmt->execute([$code]);
    $dStats = $dedupStmt->fetch();

    $totalAudited  = (int)($dStats['total_unique_audited'] ?? 0);
    $targetAudited = (int)($dStats['target_audited'] ?? 0);
    $extraAudited  = (int)($dStats['extra_audited'] ?? 0);
    $netTotalVal   = (float)($dStats['branch_net_total'] ?? 0.0);
    $pendingItems  = max(0, $targetItemsCount - $targetAudited);

    $completionPercent = $targetItemsCount > 0 ? round(($targetAudited / $targetItemsCount) * 100, 1) : 0.0;

    // Totals accumulation
    $totalAllTargets           += $targetItemsCount;
    $totalAllAudited           += $totalAudited;
    $totalAllTargetAudited     += $targetAudited;
    $totalAllExtraAudited      += $extraAudited;
    $totalAllPending           += $pendingItems;
    $totalAllFinancialVariance += $netTotalVal;

    $masterData[] = [
        'code'               => $code,
        'name'               => $branchName,
        'auditor'            => $auditorName,
        'daily_target'       => $dailyTarget,
        'target_days'        => $targetDays,
        'target_items'       => $targetItemsCount,
        'total_audited'      => $totalAudited,
        'target_audited'     => $targetAudited,
        'extra_audited'      => $extraAudited,
        'pending_items'      => $pendingItems,
        'completion_percent' => $completionPercent,
        'financial_variance' => $netTotalVal
    ];
}

$overallProgressPercent = $totalAllTargets > 0 ? round(($totalAllTargetAudited / $totalAllTargets) * 100, 1) : 0.0;
?>

<!-- Header Section -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">Option 5: Master Working Report</h3>
        <p class="text-muted m-0">Consolidated executive review across all branches, targets achieved, and net financial impacts.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="import.php" class="btn btn-outline-primary fw-bold">
            <i class="bi bi-cloud-arrow-up me-1"></i> Quick Daily Upload
        </a>
        <a href="actions/export_excel.php?type=branch_summary" class="btn btn-success fw-bold shadow-sm">
            <i class="bi bi-file-earmark-excel me-1"></i> Export Master Report to Excel
        </a>
    </div>
</div>

<!-- Grand Total KPI Bar -->
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card card-custom p-3 border-start border-primary border-4 shadow-sm">
            <span class="text-muted small fw-bold text-uppercase">Total Target Items</span>
            <h3 class="fw-bold text-dark m-0 mt-1"><?= number_format($totalAllTargets) ?></h3>
            <span class="text-muted small">All 9 Branches</span>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card card-custom p-3 border-start border-success border-4 shadow-sm">
            <span class="text-muted small fw-bold text-uppercase">Verified Targets Audited</span>
            <h3 class="fw-bold text-success m-0 mt-1"><?= number_format($totalAllTargetAudited) ?></h3>
            <span class="text-success small fw-bold"><?= $overallProgressPercent ?>% Completed</span>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card card-custom p-3 border-start border-danger border-4 shadow-sm">
            <span class="text-muted small fw-bold text-uppercase">Pending Items</span>
            <h3 class="fw-bold text-danger m-0 mt-1"><?= number_format($totalAllPending) ?></h3>
            <span class="text-muted small">Remaining to Audit</span>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card card-custom p-3 border-start <?= $totalAllFinancialVariance >= 0 ? 'border-success' : 'border-danger' ?> border-4 shadow-sm">
            <span class="text-muted small fw-bold text-uppercase">Net Financial Variance</span>
            <h3 class="fw-bold <?= $totalAllFinancialVariance >= 0 ? 'text-success' : 'text-danger' ?> m-0 mt-1">
                PKR <?= number_format($totalAllFinancialVariance, 2) ?>
            </h3>
            <span class="small <?= $totalAllFinancialVariance >= 0 ? 'text-success' : 'text-danger' ?>">
                <?= $totalAllFinancialVariance >= 0 ? 'Net Excess Surplus' : 'Net Shortage Deficit' ?>
            </span>
        </div>
    </div>
</div>

<!-- Master Progress Table -->
<div class="card card-custom shadow-sm mb-4">
    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold"><i class="bi bi-journal-check text-primary me-2"></i> Comprehensive Branch-Wise Working Summary</h5>
        <span class="badge bg-primary fs-6">9 Operational Branches</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Branch</th>
                        <th>Current Auditor</th>
                        <th class="text-center">Daily Target</th>
                        <th class="text-center">Target Days</th>
                        <th class="text-end">Target Items</th>
                        <th class="text-end">Total Audited</th>
                        <th class="text-end">Target Audited</th>
                        <th class="text-end">Extra Items</th>
                        <th class="text-end">Pending Items</th>
                        <th style="width: 150px;">Completion %</th>
                        <th class="text-end">Net Amount Diff</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($masterData as $row): ?>
                        <tr>
                            <td>
                                <span class="badge bg-primary fs-6 me-1"><?= $row['code'] ?></span>
                                <span class="fw-bold"><?= htmlspecialchars($row['name']) ?></span>
                            </td>
                            <td>
                                <i class="bi bi-person-fill text-secondary me-1"></i>
                                <span class="fw-semibold <?= $row['auditor'] === 'Unassigned' ? 'text-danger' : 'text-dark' ?>">
                                    <?= htmlspecialchars($row['auditor']) ?>
                                </span>
                            </td>
                            <td class="text-center"><?= number_format($row['daily_target']) ?></td>
                            <td class="text-center"><?= number_format($row['target_days'], 1) ?></td>
                            <td class="text-end fw-bold"><?= number_format($row['target_items']) ?></td>
                            <td class="text-end fw-bold text-primary"><?= number_format($row['total_audited']) ?></td>
                            <td class="text-end fw-bold text-success"><?= number_format($row['target_audited']) ?></td>
                            <td class="text-end fw-bold text-warning"><?= number_format($row['extra_audited']) ?></td>
                            <td class="text-end fw-bold text-danger"><?= number_format($row['pending_items']) ?></td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="progress flex-grow-1" style="height: 6px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: <?= min(100, $row['completion_percent']) ?>%"></div>
                                    </div>
                                    <small class="fw-bold"><?= $row['completion_percent'] ?>%</small>
                                </div>
                            </td>
                            <td class="text-end fw-bold <?= $row['financial_variance'] >= 0 ? 'text-success' : 'text-danger' ?>">
                                PKR <?= number_format($row['financial_variance'], 2) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="table-light fw-bold">
                    <tr>
                        <td colspan="4" class="text-uppercase text-center">Grand Total / Overall System Progress:</td>
                        <td class="text-end"><?= number_format($totalAllTargets) ?></td>
                        <td class="text-end text-primary"><?= number_format($totalAllAudited) ?></td>
                        <td class="text-end text-success"><?= number_format($totalAllTargetAudited) ?></td>
                        <td class="text-end text-warning"><?= number_format($totalAllExtraAudited) ?></td>
                        <td class="text-end text-danger"><?= number_format($totalAllPending) ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="progress flex-grow-1" style="height: 6px;">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: <?= min(100, $overallProgressPercent) ?>%"></div>
                                </div>
                                <small><?= $overallProgressPercent ?>%</small>
                            </div>
                        </td>
                        <td class="text-end <?= $totalAllFinancialVariance >= 0 ? 'text-success' : 'text-danger' ?>">
                            PKR <?= number_format($totalAllFinancialVariance, 2) ?>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>