<?php
/**
 * Phase 1 Connection & Setup Verification
 * File: test_connection.php
 */

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';

// Database se branches check karte hain
$stmt = $pdo->query("SELECT code, name, aliases FROM branches ORDER BY id ASC");
$branches = $stmt->fetchAll();

$sampleTests = [
    'EME SOCIETY',
    'BAHRIA TOWN',
    'Al-Kabir Town',
    'warehouse ',
    'KB'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Phase 1 - Setup Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">
    <div class="container" style="max-width: 850px;">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-success text-white py-3">
                <h4 class="m-0">Phase 1: Setup Successfully Verified!</h4>
            </div>
            <div class="card-body">
                <div class="alert alert-success d-flex align-items-center">
                    <strong>Status:</strong> &nbsp; Database <code>stock_audit_db</code> connected successfully via PDO!
                </div>

                <h5 class="mt-4">1. Branches Loaded from Database:</h5>
                <table class="table table-bordered table-striped mt-2">
                    <thead class="table-dark">
                        <tr>
                            <th>Code</th>
                            <th>Branch Name</th>
                            <th>Configured Aliases</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($branches as $b): ?>
                        <tr>
                            <td><span class="badge bg-primary fs-6"><?= htmlspecialchars($b['code']) ?></span></td>
                            <td><?= htmlspecialchars($b['name']) ?></td>
                            <td><small class="text-muted"><?= htmlspecialchars($b['aliases']) ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <h5 class="mt-4">2. Branch Normalizer Test:</h5>
                <ul class="list-group">
                    <?php foreach ($sampleTests as $testStr): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Excel Input: <code>"<?= htmlspecialchars($testStr) ?>"</code>
                            <span class="badge bg-success rounded-pill fs-6">Normalized: <?= normalizeBranchCode($testStr) ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <div class="mt-4 p-3 bg-light border rounded text-center">
                    <p class="text-success fw-bold m-0">Zabardast! Phase 1 complete ho gaya hai.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>