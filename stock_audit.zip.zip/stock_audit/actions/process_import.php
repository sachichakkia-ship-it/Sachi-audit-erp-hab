<?php
/**
 * High-Speed XLSX/CSV Import Engine (Zero Dependency, Native Fast XML/CSV Parser)
 * File: actions/process_import.php
 */
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/constants.php';

ini_set('memory_limit', '1024M');
ini_set('max_execution_time', '900'); // 15 mins for large 40k row datasets

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['excel_file'])) {
    header("Location: ../import.php?status=error&msg=Koi file select nahi ki gayi");
    exit;
}

$file = $_FILES['excel_file'];
$mode = $_POST['import_mode'] ?? 'daily_adjustment';

if ($file['error'] !== UPLOAD_ERR_OK) {
    header("Location: ../import.php?status=error&msg=File upload error");
    exit;
}

$fileName = $file['name'];
$tmpPath = $file['tmp_name'];
$ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

/**
 * Native Simple XLSX Sheet Reader using ZipArchive + SimpleXML
 */
class FastXlsxReader
{
    private string $filePath;
    private array $sharedStrings = [];
    private array $sheetMap = [];

    public function __construct(string $filePath)
    {
        $this->filePath = $filePath;
        $this->parseWorkbook();
    }

    private function parseWorkbook(): void
    {
        $zip = new ZipArchive();
        if ($zip->open($this->filePath) !== true) {
            throw new Exception("XLSX archive open nahi ho saka.");
        }

        // Shared strings parse karna
        $xmlStrings = $zip->getFromName('xl/sharedStrings.xml');
        if ($xmlStrings !== false) {
            $xml = simplexml_load_string($xmlStrings);
            foreach ($xml->si as $val) {
                if (isset($val->t)) {
                    $this->sharedStrings[] = (string)$val->t;
                } elseif (isset($val->r)) {
                    $t = '';
                    foreach ($val->r as $part) {
                        $t .= (string)$part->t;
                    }
                    $this->sharedStrings[] = $t;
                } else {
                    $this->sharedStrings[] = '';
                }
            }
        }

        // Workbook sheets extract karna
        $wbXml = $zip->getFromName('xl/workbook.xml');
        if ($wbXml !== false) {
            $xml = simplexml_load_string($wbXml);
            $i = 1;
            foreach ($xml->sheets->sheet as $sh) {
                $name = (string)$sh['name'];
                $this->sheetMap[trim($name)] = "xl/worksheets/sheet{$i}.xml";
                $i++;
            }
        }

        $zip->close();
    }

    public function readSheetRows(string $targetSheetName): Generator
    {
        $sheetPath = null;
        foreach ($this->sheetMap as $name => $path) {
            if (strcasecmp(trim($name), trim($targetSheetName)) === 0) {
                $sheetPath = $path;
                break;
            }
        }

        if (!$sheetPath) {
            return;
        }

        $zip = new ZipArchive();
        $zip->open($this->filePath);
        $stream = $zip->getStream($sheetPath);

        if (!$stream) {
            $zip->close();
            return;
        }

        $xmlReader = new XMLReader();
        $xmlReader->xml(stream_get_contents($stream));
        fclose($stream);
        $zip->close();

        while ($xmlReader->read()) {
            if ($xmlReader->nodeType === XMLReader::ELEMENT && $xmlReader->name === 'row') {
                $rowXml = simplexml_load_string($xmlReader->readOuterXml());
                $rowData = [];
                foreach ($rowXml->c as $cell) {
                    $type = (string)$cell['t'];
                    $val = (string)$cell->v;
                    if ($type === 's' && isset($this->sharedStrings[(int)$val])) {
                        $rowData[] = $this->sharedStrings[(int)$val];
                    } else {
                        $rowData[] = $val;
                    }
                }
                yield $rowData;
            }
        }
        $xmlReader->close();
    }
}

function parseAuditDate($raw): string
{
    if (empty($raw)) return date('Y-m-d');
    if (is_numeric($raw)) {
        $unix = ((int)$raw - 25569) * 86400;
        return gmdate('Y-m-d', $unix);
    }
    $time = strtotime((string)$raw);
    return $time ? date('Y-m-d', $time) : date('Y-m-d');
}

try {
    $pdo->beginTransaction();

    $logStmt = $pdo->prepare("INSERT INTO import_logs (file_name, sheet_name, status) VALUES (?, ?, 'PROCESSING')");
    $logStmt->execute([$fileName, $mode === 'master_workbook' ? 'All (3 Sheets)' : 'AJSTMINTS']);
    $batchId = (int)$pdo->lastInsertId();

    $totalProcessed = 0;

    if ($mode === 'master_workbook') {
        $xlsx = new FastXlsxReader($tmpPath);

        // 1. SHEET 'itrems ' (Target Items)
        $targetBatch = [];
        $headerSkipped = false;
        foreach ($xlsx->readSheetRows('itrems') as $row) {
            if (!$headerSkipped) { $headerSkipped = true; continue; }
            if (empty($row) || empty($row[3])) continue;

            $targetBatch[] = [
                $batchId,
                normalizeBranchCode((string)($row[0] ?? '')),
                trim((string)($row[1] ?? '')),
                trim((string)($row[2] ?? '')),
                trim((string)($row[3] ?? '')),
                trim((string)($row[4] ?? '')),
                trim((string)($row[5] ?? '')),
                (float)($row[6] ?? 0),
                (float)($row[7] ?? 0)
            ];

            if (count($targetBatch) >= 500) {
                insertTargetBatch($pdo, $targetBatch);
                $totalProcessed += count($targetBatch);
                $targetBatch = [];
            }
        }
        if (!empty($targetBatch)) {
            insertTargetBatch($pdo, $targetBatch);
            $totalProcessed += count($targetBatch);
        }

        // 2. SHEET 'TARGATS' (Auditors & Branch Targets)
        $headerSkipped = false;
        foreach ($xlsx->readSheetRows('TARGATS') as $row) {
            if (!$headerSkipped) { $headerSkipped = true; continue; }
            if (empty($row[0])) continue;

            $auditorName = trim((string)$row[0]);
            $dailyTarget = (int)($row[1] ?? 300);
            $branchCode  = normalizeBranchCode((string)($row[2] ?? ''));
            $targetDays  = (float)($row[3] ?? 0);

            $aStmt = $pdo->prepare("SELECT id FROM auditors WHERE name = ? LIMIT 1");
            $aStmt->execute([$auditorName]);
            $auditorId = $aStmt->fetchColumn();

            if (!$auditorId) {
                $insA = $pdo->prepare("INSERT INTO auditors (name) VALUES (?)");
                $insA->execute([$auditorName]);
                $auditorId = (int)$pdo->lastInsertId();
            }

            if ($branchCode) {
                $chkTrans = $pdo->prepare("SELECT id FROM auditor_transfers WHERE auditor_id = ? AND branch_code = ? AND end_date IS NULL");
                $chkTrans->execute([$auditorId, $branchCode]);
                if (!$chkTrans->fetchColumn()) {
                    $insTrans = $pdo->prepare("
                        INSERT INTO auditor_transfers (auditor_id, branch_code, daily_target_items, target_days, start_date)
                        VALUES (?, ?, ?, ?, CURDATE())
                    ");
                    $insTrans->execute([$auditorId, $branchCode, $dailyTarget, $targetDays]);
                }
            }
        }

        // 3. SHEET 'AJSTMINTS' (Adjustments)
        $adjBatch = [];
        $headerSkipped = false;
        foreach ($xlsx->readSheetRows('AJSTMINTS') as $row) {
            if (!$headerSkipped) { $headerSkipped = true; continue; }
            if (empty($row) || empty($row[3])) continue;

            $status = strtoupper(trim((string)($row[6] ?? 'SHORT')));
            if (!in_array($status, ['SHORT', 'EXCESS'])) $status = 'SHORT';

            $adjBatch[] = [
                $batchId,
                normalizeBranchCode((string)($row[0] ?? '')),
                parseAuditDate($row[1] ?? ''),
                trim((string)($row[2] ?? '')),
                trim((string)$row[3]),
                trim((string)($row[4] ?? '')),
                trim((string)($row[5] ?? '')),
                $status,
                (float)($row[7] ?? 0),
                (float)($row[8] ?? 0),
                (float)($row[9] ?? 0),
                trim((string)($row[10] ?? ''))
            ];

            if (count($adjBatch) >= 500) {
                insertAdjustmentBatch($pdo, $adjBatch);
                $totalProcessed += count($adjBatch);
                $adjBatch = [];
            }
        }
        if (!empty($adjBatch)) {
            insertAdjustmentBatch($pdo, $adjBatch);
            $totalProcessed += count($adjBatch);
        }

    } elseif ($mode === 'daily_adjustment') {
        $adjBatch = [];

        if ($ext === 'csv') {
            $handle = fopen($tmpPath, 'r');
            $headerSkipped = false;
            while (($row = fgetcsv($handle, 2000, ",")) !== false) {
                if (!$headerSkipped) { $headerSkipped = true; continue; }
                if (empty($row[3])) continue;

                $status = strtoupper(trim((string)($row[6] ?? 'SHORT')));
                if (!in_array($status, ['SHORT', 'EXCESS'])) $status = 'SHORT';

                $adjBatch[] = [
                    $batchId,
                    normalizeBranchCode((string)($row[0] ?? '')),
                    parseAuditDate($row[1] ?? ''),
                    trim((string)($row[2] ?? '')),
                    trim((string)$row[3]),
                    trim((string)($row[4] ?? '')),
                    trim((string)($row[5] ?? '')),
                    $status,
                    (float)($row[7] ?? 0),
                    (float)($row[8] ?? 0),
                    (float)($row[9] ?? 0),
                    trim((string)($row[10] ?? ''))
                ];

                if (count($adjBatch) >= 500) {
                    insertAdjustmentBatch($pdo, $adjBatch);
                    $totalProcessed += count($adjBatch);
                    $adjBatch = [];
                }
            }
            fclose($handle);
        } else {
            $xlsx = new FastXlsxReader($tmpPath);
            $headerSkipped = false;
            foreach ($xlsx->readSheetRows('AJSTMINTS') as $row) {
                if (!$headerSkipped) { $headerSkipped = true; continue; }
                if (empty($row[3])) continue;

                $status = strtoupper(trim((string)($row[6] ?? 'SHORT')));
                if (!in_array($status, ['SHORT', 'EXCESS'])) $status = 'SHORT';

                $adjBatch[] = [
                    $batchId,
                    normalizeBranchCode((string)($row[0] ?? '')),
                    parseAuditDate($row[1] ?? ''),
                    trim((string)($row[2] ?? '')),
                    trim((string)$row[3]),
                    trim((string)($row[4] ?? '')),
                    trim((string)($row[5] ?? '')),
                    $status,
                    (float)($row[7] ?? 0),
                    (float)($row[8] ?? 0),
                    (float)($row[9] ?? 0),
                    trim((string)($row[10] ?? ''))
                ];

                if (count($adjBatch) >= 500) {
                    insertAdjustmentBatch($pdo, $adjBatch);
                    $totalProcessed += count($adjBatch);
                    $adjBatch = [];
                }
            }
        }

        if (!empty($adjBatch)) {
            insertAdjustmentBatch($pdo, $adjBatch);
            $totalProcessed += count($adjBatch);
        }
    }

    $upStmt = $pdo->prepare("UPDATE import_logs SET total_rows = ?, processed_rows = ?, status = 'COMPLETED' WHERE id = ?");
    $upStmt->execute([$totalProcessed, $totalProcessed, $batchId]);

    $pdo->commit();
    header("Location: ../import.php?status=success&msg=" . urlencode("Zabardast! {$totalProcessed} rows kamyabi se import aur process ho chuki hain."));
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    if (isset($batchId)) {
        $pdo->prepare("UPDATE import_logs SET status = 'FAILED', error_log = ? WHERE id = ?")->execute([$e->getMessage(), $batchId]);
    }
    header("Location: ../import.php?status=error&msg=" . urlencode("Import Failed: " . $e->getMessage()));
    exit;
}

function insertTargetBatch(PDO $pdo, array $rows): void
{
    $placeholders = [];
    $values = [];
    foreach ($rows as $row) {
        $placeholders[] = "(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        foreach ($row as $val) {
            $values[] = $val;
        }
    }
    $sql = "INSERT INTO target_items (import_batch_id, branch_code, group_name, sub_group, item_code, barcode, item_description, max_qty, oct_sale) 
            VALUES " . implode(', ', $placeholders);
    $pdo->prepare($sql)->execute($values);
}

function insertAdjustmentBatch(PDO $pdo, array $rows): void
{
    $placeholders = [];
    $values = [];
    foreach ($rows as $row) {
        $placeholders[] = "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        foreach ($row as $val) {
            $values[] = $val;
        }
    }
    $sql = "INSERT INTO adjustments (import_batch_id, branch_code, audit_date, doc_no, item_code, barcode, item_description, status, adj_qty, price, net_total, reason) 
            VALUES " . implode(', ', $placeholders);
    $pdo->prepare($sql)->execute($values);
}