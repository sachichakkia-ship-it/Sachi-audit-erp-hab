<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/constants.php';

$type = $_GET['type'] ?? 'auditor_summary';
$filterBranch   = trim($_GET['branch'] ?? '');
$filterAuditor  = (int)($_GET['auditor_id'] ?? 0);
$filterDate     = trim($_GET['date'] ?? '');
$filterStatus   = trim($_GET['status'] ?? 'ALL');
$filterSubGroup = trim($_GET['sub_group'] ?? '');

$fileName = $type . '_' . date('Y-m-d_His') . '.csv';

// HTTP Headers for instant Excel/CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $fileName . '"');

$output = fopen('php://output', 'w');
// UTF-8 BOM for proper Excel rendering
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// 1. AUDITOR WORKING SUMMARY
if ($type === 'auditor_summary') {
    fputcsv($output, ['Branch Code', 'Auditor Name', 'Daily Target', 'Target Days', 'Total Target Items', 'Total Audited', 'Target Audited', 'Extra Audited', 'Net Amount Difference (PKR)']);

    $stmt = $pdo->query("
        SELECT 
            b.code AS branch_code,
            COALESCE(a.name, 'Unassigned') AS auditor_name,
            t.daily_target_items,
            t.target_days,
            (t.daily_target_items * t.target_days) AS total_target,
            COUNT(v.item_code) AS total_audited,
            SUM(CASE WHEN v.audit_classification = 'TARGET_AUDITED' THEN 1 ELSE 0 END) AS target_audited,
            SUM(CASE WHEN v.audit_classification = 'EXTRA_AUDITED' THEN 1 ELSE 0 END) AS extra_audited,
            COALESCE(SUM(v.total_net_value), 0) AS net_total_amount
        FROM branches b
        LEFT JOIN auditor_transfers t ON b.code = t.branch_code AND (t.end_date IS NULL OR t.end_date >= CURDATE())
        LEFT JOIN auditors a ON t.auditor_id = a.id
        LEFT JOIN view_deduplicated_audits v ON b.code = v.branch_code
        GROUP BY b.code, a.id, t.id
        ORDER BY b.code ASC
    ");

    while ($r = $stmt->fetch()) {
        fputcsv($output, [
            $r['branch_code'],
            $r['auditor_name'],
            $r['daily_target_items'] ?? 300,
            $r['target_days'] ?? 0,
            $r['total_target'] ?? 0,
            $r['total_audited'],
            $r['target_audited'],
            $r['extra_audited'],
            number_format((float)$r['net_total_amount'], 2)
        ]);
    }
}

// 2. DETAILED ADJUSTMENTS LOG
elseif ($type === 'detailed_adjustments') {
    fputcsv($output, ['Branch', 'Date', 'DOC#', 'Item Code', 'Barcode', 'Item Description', 'Status', 'ADJ QTY', 'Price', 'Net Total (PKR)', 'Reason', 'Auditor']);

    $stmt = $pdo->query("
        SELECT 
            adj.branch_code,
            adj.audit_date,
            adj.doc_no,
            adj.item_code,
            adj.barcode,
            adj.item_description,
            adj.status,
            adj.adj_qty,
            adj.price,
            adj.net_total,
            adj.reason,
            COALESCE(a.name, 'Unassigned') AS auditor_name
        FROM adjustments adj
        LEFT JOIN auditor_transfers t 
            ON adj.branch_code = t.branch_code 
            AND adj.audit_date >= t.start_date 
            AND (t.end_date IS NULL OR adj.audit_date <= t.end_date)
        LEFT JOIN auditors a ON t.auditor_id = a.id
        ORDER BY adj.audit_date DESC, adj.id DESC
        LIMIT 10000
    ");

    while ($r = $stmt->fetch()) {
        fputcsv($output, [
            $r['branch_code'],
            $r['audit_date'],
            $r['doc_no'],
            $r['item_code'],
            $r['barcode'],
            $r['item_description'],
            $r['status'],
            $r['adj_qty'],
            $r['price'],
            $r['net_total'],
            $r['reason'],
            $r['auditor_name']
        ]);
    }
}

// 3. BRANCH SUMMARY / MASTER REPORT
elseif ($type === 'branch_summary') {
    fputcsv($output, ['Branch Code', 'Branch Name', 'Target Items', 'Total Audited', 'Target Audited', 'Extra Audited', 'Pending Items', 'Net Amount Difference (PKR)']);

    $branchCodes = ['EME', 'BT', 'AB', 'KB', 'KT', 'GT', 'WT', 'MT', 'WH'];
    foreach ($branchCodes as $code) {
        $name = $pdo->query("SELECT name FROM branches WHERE code = '{$code}'")->fetchColumn();
        $targetTotal = (int)$pdo->query("SELECT COUNT(*) FROM target_items WHERE branch_code = '{$code}'")->fetchColumn();
        $auditedTotal = (int)$pdo->query("SELECT COUNT(*) FROM view_deduplicated_audits WHERE branch_code = '{$code}'")->fetchColumn();
        $targetAudited = (int)$pdo->query("SELECT COUNT(*) FROM view_deduplicated_audits WHERE branch_code = '{$code}' AND audit_classification = 'TARGET_AUDITED'")->fetchColumn();
        $extraAudited = (int)$pdo->query("SELECT COUNT(*) FROM view_deduplicated_audits WHERE branch_code = '{$code}' AND audit_classification = 'EXTRA_AUDITED'")->fetchColumn();
        $pending = max(0, $targetTotal - $targetAudited);
        $netTotal = (float)$pdo->query("SELECT COALESCE(SUM(net_total), 0) FROM adjustments WHERE branch_code = '{$code}'")->fetchColumn();

        fputcsv($output, [
            $code,
            $name,
            $targetTotal,
            $auditedTotal,
            $targetAudited,
            $extraAudited,
            $pending,
            number_format($netTotal, 2)
        ]);
    }
}

// 4. ITEMS STATUS EXPORT
elseif ($type === 'items_status') {
    fputcsv($output, ['Branch Code', 'Group', 'Sub Group', 'Item Code', 'Barcode', 'Item Description', 'Max Qty', 'Oct Sale', 'Audit Status', 'Total Adj Qty', 'Net Total (PKR)']);

    $stmt = $pdo->query("
        SELECT 
            t.branch_code,
            t.group_name,
            t.sub_group,
            t.item_code,
            t.barcode,
            t.item_description,
            t.max_qty,
            t.oct_sale,
            CASE WHEN v.item_code IS NOT NULL THEN 'AUDITED_TARGET' ELSE 'PENDING_TARGET' END AS audit_status,
            COALESCE(v.total_adj_qty, 0) AS total_adj_qty,
            COALESCE(v.total_net_value, 0) AS total_net_value
        FROM target_items t
        LEFT JOIN view_deduplicated_audits v ON t.branch_code = v.branch_code AND t.item_code = v.item_code
        ORDER BY t.branch_code ASC, t.item_code ASC
    ");

    while ($r = $stmt->fetch()) {
        fputcsv($output, [
            $r['branch_code'],
            $r['group_name'],
            $r['sub_group'],
            $r['item_code'],
            $r['barcode'],
            $r['item_description'],
            $r['max_qty'],
            $r['oct_sale'],
            $r['audit_status'],
            $r['total_adj_qty'],
            $r['total_net_value']
        ]);
    }
}

// 5. PENDING 300-ITEM BATCH EXPORT
elseif ($type === 'pending_batch') {
    $batchNo = (int)($_GET['batch_no'] ?? 1);
    $offset = ($batchNo - 1) * 300;
    $whereSubGroup = !empty($filterSubGroup) ? "AND t.sub_group = '{$filterSubGroup}'" : "";

    fputcsv($output, ['Serial #', 'Branch', 'Sub Group', 'Item Code', 'Barcode', 'Item Description', 'Max Qty', 'Oct Sale', 'Physical Count']);

    $stmt = $pdo->query("
        SELECT 
            t.branch_code,
            t.sub_group,
            t.item_code,
            t.barcode,
            t.item_description,
            t.max_qty,
            t.oct_sale
        FROM target_items t
        LEFT JOIN view_deduplicated_audits v 
            ON t.branch_code = v.branch_code 
            AND t.item_code = v.item_code
        WHERE t.branch_code = '{$filterBranch}'
          AND v.item_code IS NULL
          {$whereSubGroup}
        ORDER BY t.sub_group ASC, t.item_code ASC
        LIMIT 300 OFFSET {$offset}
    ");

    $sr = $offset + 1;
    while ($r = $stmt->fetch()) {
        fputcsv($output, [
            $sr++,
            $r['branch_code'],
            $r['sub_group'],
            $r['item_code'],
            $r['barcode'],
            $r['item_description'],
            $r['max_qty'],
            $r['oct_sale'],
            '' // Blank space for physical count
        ]);
    }
}

fclose($output);
exit;