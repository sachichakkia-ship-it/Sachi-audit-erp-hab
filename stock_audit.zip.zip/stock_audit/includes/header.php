<?php
/**
 * Master Header Layout
 * File: includes/header.php
 */
declare(strict_types=1);

if (!defined('BASE_URL')) {
    define('BASE_URL', '/stock_audit');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Stock Audit & Adjustment System' ?></title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css" rel="stylesheet">

    <!-- Custom Modern Styling -->
    <style>
        :root {
            --sidebar-width: 260px;
            --primary-navy: #0f172a;
            --accent-blue: #0284c7;
        }
        body {
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
            background-color: #f1f5f9;
            color: #334155;
        }
        #sidebar {
            width: var(--sidebar-width);
            min-height: 100vh;
            background-color: var(--primary-navy);
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            transition: all 0.3s;
        }
        #sidebar .nav-link {
            color: #94a3b8;
            padding: 12px 20px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            border-radius: 6px;
            margin: 4px 12px;
            text-decoration: none;
        }
        #sidebar .nav-link:hover, #sidebar .nav-link.active {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.1);
        }
        #sidebar .nav-link.active {
            background-color: var(--accent-blue);
        }
        #main-content {
            margin-left: var(--sidebar-width);
            padding: 24px;
            min-height: 100vh;
        }
        .card-custom {
            border: none;
            border-radius: 10px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            background: #ffffff;
        }
    </style>
</head>
<body>
<div class="d-flex">