<?php
/**
 * Master Sidebar Navigation with Creator Badge
 * File: includes/sidebar.php
 */
declare(strict_types=1);

$currentUri = $_SERVER['REQUEST_URI'] ?? '';
?>
<nav id="sidebar">
    <!-- Top Header -->
    <div class="p-3 text-white border-bottom border-secondary d-flex align-items-center gap-2">
        <i class="bi bi-boxes fs-4 text-info"></i>
        <div>
            <h6 class="m-0 fw-bold">Stock Audit Pro</h6>
            <small class="text-secondary" style="font-size: 11px;">Enterprise Auditor</small>
        </div>
    </div>

    <!-- Navigation Menu -->
    <div class="py-3" style="padding-bottom: 90px !important;">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= str_ends_with($currentUri, 'stock_audit/') || str_ends_with($currentUri, 'index.php') ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>/index.php">
                    <i class="bi bi-speedometer2"></i> Executive Dashboard
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= str_contains($currentUri, 'import.php') ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>/import.php">
                    <i class="bi bi-file-earmark-arrow-up"></i> Upload Excel / CSV
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= str_contains($currentUri, 'auditor_working.php') ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>/auditor_working.php">
                    <i class="bi bi-person-workspace"></i> Auditor Working
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= str_contains($currentUri, 'items_status.php') ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>/items_status.php">
                    <i class="bi bi-list-check"></i> Items Audit Status
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= str_contains($currentUri, 'pending_batches.php') ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>/pending_batches.php">
                    <i class="bi bi-collection"></i> 300-Item Batches
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= str_contains($currentUri, 'auditors.php') ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>/auditors.php">
                    <i class="bi bi-people"></i> Auditor Transfers
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= str_contains($currentUri, 'master_report.php') ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>/master_report.php">
                    <i class="bi bi-journal-text"></i> Master Report
                </a>
            </li>
        </ul>
    </div>

    <!-- Screenshot 2 jaisa Bottom Name Badge -->
    <div style="position: absolute; bottom: 0; left: 0; width: 100%; background: #0b1120;" class="p-3 border-top border-secondary text-center">
        <small class="text-secondary d-block text-uppercase fw-semibold" style="font-size: 10px; letter-spacing: 0.5px;">CREATED &amp; DESIGNED BY</small>
        <span class="text-info fw-bold d-inline-block mt-1" style="font-size: 13px;">
            <i class="bi bi-patch-check-fill text-primary me-1"></i> Malik Muzamil
        </span>
    </div>
</nav>

<div id="main-content" class="w-100">
    <div class="container-fluid">