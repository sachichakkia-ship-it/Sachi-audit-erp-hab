<?php
/**
 * Option 1: Auditor & Branch Working Performance
 * File: auditor_working.php
 */
declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';

$pageTitle = 'Auditor & Branch Working | Stock Audit Pro';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Filter Values
$filterBranch  = trim($_GET['branch'] ?? '');
$filterAuditor = (int)($_GET['auditor_id'] ?? 0);
$filterDate    = trim($_GET['date'] ?? '');

// 1. Fetch Branches for Filter Dropdown
$branches = $pdo->query("SELECT code, name FROM branches ORDER BY name ASC")->fetchAll();

// 2. Fetch Auditors for Filter Dropdown
$auditors = $pdo->query("SELECT id, name FROM auditors ORDER BY name ASC")->fetchAll();

// 3. Build Dynamic Working Query
// Links audits to the correct auditor based on the audit_date matching the transfer date range
$whereClauses = [];
$params = [];

if (!empty($filterBranch)) {
    $whereClauses[] = "b.code = :branch";
    $params[':branch'] = $filterBranch;
}
if ($filterAuditor > 0) {
    $whereClauses[] = "a.id = :auditor_id";
    $params[':auditor_id'] = $filterAuditor;
}
if (!empty($filterDate)) {
    $whereClauses[] = "v.audit_date = :audit_date";
    $params[':audit_date'] = $filterDate;
}

$whereSql = !empty($whereClauses) ? "WHERE " . implode(" AND ", $whereClauses) : "";

// Consolidated working query
$query = "
    SELECT 
        b.code AS branch_code,
        b.name AS branch_name,
        COALESCE(a.name, 'Unassigned') AS auditor_name,
        t.daily_target_items,
        t.target_days,
        (t.daily_target_items * t.target_days) AS total_target_items,
        COUNT(v.item_code) AS total_audited,
        SUM(CASE WHEN v.audit_classification = 'TARGET_AUDITED' THEN 1 ELSE 0 END) AS target_audited,
        SUM(CASE WHEN v.audit_classification = 'EXTRA_AUDITED' THEN 1 ELSE 0 END) AS extra_audited,
        COALESCE(SUM(v.total_net_value), 0) AS net_total_amount
    FROM branches b
    LEFT JOIN auditor_transfers t 
        ON b.code = t.branch_code 
        AND (t.end_date IS NULL OR t.end_date >= CURDATE())
    LEFT JOIN auditors a 
        ON t.auditor_id = a.id
    LEFT JOIN view_deduplicated_audits v 
        ON b.code = v.branch_code
        AND (t.start_date IS NULL OR (v.audit_date >= t.start_date AND (t.end_date IS NULL OR v.audit_date <= t.end_date)))
    {$whereSql}
    GROUP BY b.code, a.id, t.id
    ORDER BY b.code ASC
";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$workingData = $stmt->fetchAll();

// Excel Export URL query string
$exportQuery = http_build_query([
    'branch'     => $filterBranch,
    'auditor_id' => $filterAuditor,
    'date'       => $filterDate
]);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">Option 1: Auditor & Branch Working</h3>
        <p class="text-muted m-0">Daily targets vs actual scans, extra item tracking, and financial variance.</p>
    </div>
    <!-- 3 Excel Download Buttons -->
    <div class="dropdown">
        <button class="btn btn-success dropdown-toggle fw-bold" type="button" data-bs-toggle="dropdown">
            <i class="bi bi-file-earmark-excel me-1"></i> Download Excel Reports
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow">
            <li>
                <a class="dropdown-item py-2" href="actions/export_excel.php?type=auditor_summary&<?= $exportQuery ?>">
                    <i class="bi bi-person-check text-success me-2"></i> 1. Auditor Working Summary
                </a>
            </li>
            <li>
                <a class="dropdown-item py-2" href="actions/export_excel.php?type=detailed_adjustments&<?= $exportQuery ?>">
                    <i class="bi bi-card-list text-primary me-2"></i> 2. Detailed Item Adjustments Log
                </a>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
                <a class="dropdown-item py-2" href="actions/export_excel.php?type=branch_summary&<?= $exportQuery ?>">
                    <i class="bi bi-building text-info me-2"></i> 3. Branch Performance Summary
                </a>
            </li>
        </ul>
    </div>
</div>

<!-- Filters Card -->
<div class="card card-custom p-3 mb-4 shadow-sm">
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-3">
            <label class="form-label fw-bold small text-muted">Filter by Branch:</label>
            <select name="branch" class="form-select">
                <option value="">-- All Branches --</option>
                <?php foreach ($branches as $br): ?>
                    <option value="<?= $br['code'] ?>" <?= $filterBranch === $br['code'] ? 'selected' : '' ?>>
                        [<?= $br['code'] ?>] <?= htmlspecialchars($br['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3">
            <label class="form-label fw-bold small text-muted">Filter by Auditor:</label>
            <select name="auditor_id" class="form-select