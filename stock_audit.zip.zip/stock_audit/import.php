<?php
/**
 * Excel / CSV Import Center
 * File: import.php
 */
declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';

$pageTitle = 'Import Excel / CSV Data | Stock Audit Pro';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Fetch recent 10 import logs
$logsStmt = $pdo->query("SELECT * FROM import_logs ORDER BY id DESC LIMIT 10");
$logs = $logsStmt->fetchAll();
?>

<div class="row mb-4">
    <div class="col">
        <h3 class="fw-bold mb-1">Excel & CSV Data Import</h3>
        <p class="text-muted m-0">Master initial workbook (3-sheets) ya daily adjustment files ko upload aur process karein.</p>
    </div>
</div>

<?php if (isset($_GET['status'])): ?>
    <?php if ($_GET['status'] === 'success'): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <strong>Kamyabi!</strong> <?= htmlspecialchars($_GET['msg'] ?? 'File kamyabi se process ho chuki hai.') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php else: ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <strong>Error!</strong> <?= htmlspecialchars($_GET['msg'] ?? 'Import mein masla aya hai.') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
<?php endif; ?>

<!-- Tabs: Master Workbook vs Daily Adjustments -->
<ul class="nav nav-pills mb-4" id="importTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active px-4 py-2 fw-semibold" id="master-tab" data-bs-toggle="pill" data-bs-target="#master-pane" type="button" role="tab">
            <i class="bi bi-file-earmark-spreadsheet me-2"></i> Mode 1: Master Workbook (3-Sheets)
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link px-4 py-2 fw-semibold" id="daily-tab" data-bs-toggle="pill" data-bs-target="#daily-pane" type="button" role="tab">
            <i class="bi bi-clock-history me-2"></i> Mode 2: Daily Adjustments File
        </button>
    </li>
</ul>

<div class="tab-content" id="importTabsContent">
    <!-- Tab 1: Master Workbook (itrems , TARGATS, AJSTMINTS) -->
    <div class="tab-pane fade show active" id="master-pane" role="tabpanel">
        <div class="card card-custom p-4 mb-4">
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <h5 class="fw-bold text-dark">Initial 3-Sheet Master Workbook Import</h5>
                    <p class="text-muted small mb-3">
                        Yeh option aapki master Excel file ke teeno sheets ko aik sath read karta hai:<br>
                        1. <code>itrems </code> (Target List: ~40,686 rows)<br>
                        2. <code>TARGATS</code> (Auditors, daily target 300, aur branch target days)<br>
                        3. <code>AJSTMINTS</code> (Initial adjustment records)
                    </p>
                    <form action="actions/process_import.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="import_mode" value="master_workbook">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Select Master Excel File (.xlsx):</label>
                            <input type="file" name="excel_file" class="form-control form-control-lg" accept=".xlsx" required>
                        </div>
                        <button type="submit" class="btn btn-primary px-4 py-2 fw-bold" onclick="showLoader(this)">
                            <i class="bi bi-cloud-arrow-up me-2"></i> Upload & Process Master File
                        </button>
                    </form>
                </div>
                <div class="col-lg-5 border-start ps-lg-4 mt-4 mt-lg-0">
                    <div class="bg-light p-3 rounded">
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-shield-check text-success me-1"></i> Auto Normalization Rules</h6>
                        <p class="small text-muted mb-2">Branches automatically detect hokar standard codes ban jayengi:</p>
                        <div class="row small text-secondary">
                            <div class="col-6">&bull; ASIF BLOCK &rarr; <b>AB</b></div>
                            <div class="col-6">&bull; BAHRIA TOWN &rarr; <b>BT</b></div>
                            <div class="col-6">&bull; EME SOCIETY &rarr; <b>EME</b></div>
                            <div class="col-6">&bull; AL-KABEER &rarr; <b>KT</b></div>
                            <div class="col-6">&bull; GARDEN TOWN &rarr; <b>GT</b></div>
                            <div class="col-6">&bull; WAPDA TOWN &rarr; <b>WT</b></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tab 2: Daily Adjustments File -->
    <div class="tab-pane fade" id="daily-pane" role="tabpanel">
        <div class="card card-custom p-4 mb-4">
            <h5 class="fw-bold text-dark">Daily AJSTMINTS Upload</h5>
            <p class="text-muted small mb-3">
                Rozana branch audit ki file (Excel .xlsx ya CSV format) yahan upload karein. System duplicate rows ko ignore karke pending batches aur dashboard stats ko foran update karega.
            </p>
            <form action="actions/process_import.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="import_mode" value="daily_adjustment">
                <div class="row">
                    <div class="col-md-7 mb-3">
                        <label class="form-label fw-bold">Select File (.xlsx ya .csv):</label>
                        <input type="file" name="excel_file" class="form-control form-control-lg" accept=".xlsx,.csv" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-success px-4 py-2 fw-bold" onclick="showLoader(this)">
                    <i class="bi bi-file-earmark-arrow-up me-2"></i> Process Daily Adjustments
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Upload Logs Table -->
<div class="card card-custom">
    <div class="card-header bg-white py-3 border-bottom">
        <h5 class="m-0 fw-bold"><i class="bi bi-clock-history me-2 text-primary"></i> Upload Logs History</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Batch #</th>
                        <th>File Name</th>
                        <th>Mode / Sheet</th>
                        <th>Total Rows</th>
                        <th>Processed Rows</th>
                        <th>Status</th>
                        <th>Imported At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">Abhi tak koi file upload nahi hui.</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td><b>#<?= $log['id'] ?></b></td>
                                <td class="fw-bold"><?= htmlspecialchars($log['file_name']) ?></td>
                                <td><span class="badge bg-secondary"><?= htmlspecialchars($log['sheet_name']) ?></span></td>
                                <td><?= number_format((int)$log['total_rows']) ?></td>
                                <td class="text-success fw-bold"><?= number_format((int)$log['processed_rows']) ?></td>
                                <td>
                                    <?php if ($log['status'] === 'COMPLETED'): ?>
                                        <span class="badge bg-success">COMPLETED</span>
                                    <?php elseif ($log['status'] === 'FAILED'): ?>
                                        <span class="badge bg-danger">FAILED</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark"><?= $log['status'] ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><small class="text-muted"><?= date('d M, Y h:i A', strtotime($log['created_at'])) ?></small></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function showLoader(btn) {
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Processing (File badi hai, kuch seconds wait karein)...';
    btn.classList.add('disabled');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>