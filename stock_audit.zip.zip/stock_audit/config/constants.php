<?php
/**
 * Branch Name Normalizer & System Constants
 * File: config/constants.php
 */

declare(strict_types=1);

/**
 * Excel sheet se aane wale kisi bhi branch name ko standard branch code mein normalize karta hai
 */
function normalizeBranchCode(string $rawBranch): string
{
    $clean = trim($rawBranch);
    $clean = preg_replace('/\s+/', ' ', $clean);
    $cleanUpper = strtoupper($clean);

    $exactMap = [
        'EME SOCIETY'     => 'EME',
        'EME'             => 'EME',
        'BAHRIA TOWN'     => 'BT',
        'BT'              => 'BT',
        'ASIF BLOCK'      => 'AB',
        'AB'              => 'AB',
        'KARIM BLOCK'     => 'KB',
        'KB'              => 'KB',
        'AL-KABEER TOWN'  => 'KT',
        'AL-KABIR TOWN'   => 'KT',
        'KT'              => 'KT',
        'GARDEN TOWN'     => 'GT',
        'GT'              => 'GT',
        'WAPDA TOWN'      => 'WT',
        'WT'              => 'WT',
        'MUSTAFA TOWN'    => 'MT',
        'MT'              => 'MT',
        'WAREHOUSE'       => 'WH',
        'WH'              => 'WH'
    ];

    if (isset($exactMap[$cleanUpper])) {
        return $exactMap[$cleanUpper];
    }

    foreach ($exactMap as $key => $code) {
        if (str_contains($cleanUpper, $key)) {
            return $code;
        }
    }

    return substr(preg_replace('/[^A-Z0-9]/', '', $cleanUpper), 0, 10);
}