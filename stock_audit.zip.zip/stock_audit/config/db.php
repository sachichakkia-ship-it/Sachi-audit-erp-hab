<?php
/**
 * Database Connection & Global Runtime Settings
 * File: config/db.php
 */

declare(strict_types=1);

// Import processes ke liye memory aur execution limit
ini_set('memory_limit', '1024M');
ini_set('max_execution_time', '600');

// Database Credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'stock_audit_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_PORT', '3306');
define('DB_CHARSET', 'utf8mb4');

class Database
{
    private static ?PDO $instance = null;

    private function __construct() {}

    public static function getConnection(): PDO
    {
        if (self::$instance === null) {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                DB_HOST,
                DB_PORT,
                DB_NAME,
                DB_CHARSET
            );

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];

            try {
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                error_log('[DB Error] ' . $e->getMessage());
                die('<div style="font-family:sans-serif;padding:20px;background:#ffe6e6;color:#990000;border:1px solid #cc0000;border-radius:6px;max-width:600px;margin:40px auto;">
                        <h3 style="margin-top:0;">Database Connection Failed</h3>
                        <p>MySQL server se connection nahi ho saka. Make sure XAMPP mein MySQL "Start" ho.</p>
                        <p><strong>Error details:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>
                     </div>');
            }
        }

        return self::$instance;
    }

    /**
     * Past audits keep previous auditor; new audits map to transferred auditor.
     */
    public static function getAuditorForAudit(string $branchCode, string $auditDate): ?array
    {
        $pdo = self::getConnection();
        $stmt = $pdo->prepare("
            SELECT 
                a.id AS auditor_id,
                a.name AS auditor_name,
                t.daily_target_items,
                t.target_days,
                t.start_date,
                t.end_date
            FROM auditor_transfers t
            INNER JOIN auditors a ON t.auditor_id = a.id
            WHERE t.branch_code = :branch_code
              AND :audit_date >= t.start_date
              AND (t.end_date IS NULL OR :audit_date <= t.end_date)
            ORDER BY t.start_date DESC
            LIMIT 1
        ");

        $stmt->execute([
            ':branch_code' => $branchCode,
            ':audit_date'  => $auditDate
        ]);

        $res = $stmt->fetch();
        return $res ?: null;
    }
}

// Global handle
$pdo = Database::getConnection();