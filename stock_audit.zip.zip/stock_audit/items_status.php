<?php
/**
 * Option 2: Items Audit Status & Tracking
 * File: items_status.php
 */
declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';

$pageTitle = 'Items Audit Status | Stock Audit Pro';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Filter Values
$filterBranch = trim($_GET['branch'] ?? '');
$filterStatus = trim($_GET['status'] ?? 'ALL'); // ALL, TARGET_AUDITED, PENDING_TARGET, EXTRA_AUDITED

// Fetch Branches for Filter Dropdown
$branches = $pdo->query("SELECT code, name FROM branches ORDER BY name ASC")->fetchAll();

// ==========================================
// DYNAMIC QUERY BUILDING
// ==========================================
// 1. Target Items with their audit status
// 2. Extra items scanned in adjustments that don't exist in target_items
$whereBranch = !empty($filterBranch) ? "WHERE branch_code = :branch" : "";
$params = !empty($filterBranch) ? [':branch' => $filterBranch] : [];

$query = "
    SELECT 
        t.branch_code,
        t.group_name,
        t.sub_group,
        t.item_code,
        t.barcode,
        t.item_description,
        t.max_qty,
        t.oct_sale,
        CASE 
            WHEN v.item_code IS NOT NULL THEN 'AUDITED_TARGET'
            ELSE 'PENDING_TARGET'
        END AS audit_status,
        COALESCE(v.raw_scan_occurrences, 0) AS scan_count,
        COALESCE(v.total_adj_qty, 0) AS total_adj_qty,
        COALESCE(v.total_net_value, 0) AS total_net_value,
        v.audit_date
    FROM target_items t
    LEFT JOIN view_deduplicated_audits v 
        ON t.branch_code = v.branch_code 
        AND t.item_code = v.item_code
    {$whereBranch}

    UNION ALL

    -- Extra Items Audited (Exist in adjustments but not in target_items for that branch)
    SELECT 
        v.branch_code,
        'EXTRA' AS group_name,
        'NON-TARGET' AS sub_group,
        v.item_code,
        v.barcode,
        v.item_description,
        0.00 AS max_qty,
        0.00 AS oct_sale,
        'EXTRA_AUDITED' AS audit_status,
        v.raw_scan_occurrences AS scan_count,
        v.total_adj_qty,
        v.total_net_value,
        v.audit_date
    FROM view_deduplicated_audits v
    WHERE v.audit_classification = 'EXTRA_AUDITED'
    " . (!empty($filterBranch) ? " AND v.branch_code = :branch" : "") . "
    ORDER BY branch_code ASC, item_code ASC
    LIMIT 2000
";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$items = $stmt->fetchAll();

// Status filter on PHP side for fast UI filtering
if ($filterStatus !== 'ALL') {
    $items = array_filter($items, function($it) use ($filterStatus) {
        return $it['audit_status'] === $filterStatus;
    });
}

// Excel Export URL query string
$exportQuery = http_build_query([
    'type'   => 'items_status',
    'branch' => $filterBranch,
    'status' => $filterStatus
]);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">Option 2: Items Audit Status</h3>
        <p class="text-muted m-0">Track all target items, verified scans, pending items, and extra items scanned.</p>
    </div>
    <a href="actions/export_excel.php?<?= $exportQuery ?>" class="btn btn-success fw-bold">
        <i class="bi bi-file-earmark-excel me-1"></i> Export Items to Excel
    </a>
</div>

<!-- Filters Card -->
<div class="card card-custom p-3 mb-4 shadow-sm">
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-4">
            <label class="form-label fw-bold small text-muted">Select Branch:</label>
            <select name="branch" class="form-select">
                <option value="">-- All Branches (Overall) --</option>
                <?php foreach ($branches as $br): ?>
                    <option value="<?= $br['code'] ?>" <?= $filterBranch === $br['code'] ? 'selected' : '' ?>>
                        [<?= $br['code'] ?>] <?= htmlspecialchars($br['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-5">
            <label class="form-label fw-bold small text-muted">Filter by Status:</label>
            <select name="status" class="form-select">
                <option value="ALL" <?= $filterStatus === 'ALL' ? 'selected' : '' ?>>Show All (Target + Pending + Extra)</option>
                <option value="AUDITED_TARGET" <?= $filterStatus === 'AUDITED_TARGET' ? 'selected' : '' ?>>Audited Target Items (Scanned & Matched)</option>
                <option value="PENDING_TARGET" <?= $filterStatus === 'PENDING_TARGET' ? 'selected' : '' ?>>Pending Target Items (Not Yet Audited)</option>
                <option value="EXTRA_AUDITED" <?= $filterStatus === 'EXTRA_AUDITED' ? 'selected' : '' ?>>Extra Non-Target Items (Scanned Outside Target)</option>
            </select>
        </div>

        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-primary w-100 fw-bold">
                <i class="bi bi-funnel me-1"></i> Apply Filter
            </button>
            <a href="items_status.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-counterclockwise"></i>
            </a>
        </div>
    </form>
</div>

<!-- Items Table Card -->
<div class="card card-custom shadow-sm">
    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold"><i class="bi bi-boxes text-primary me-2"></i> Items Status List</h5>
        <span class="badge bg-secondary fs-6"><?= count($items) ?> Records Displayed (Max 2,000 for browser speed)</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle datatable">
                <thead class="table-dark">
                    <tr>
                        <th>Branch</th>
                        <th>Status</th>
                        <th>Code</th>
                        <th>Barcode</th>
                        <th>Item Description</th>
                        <th>Sub Group</th>
                        <th>Max Qty</th>
                        <th>Scanned Qty</th>
                        <th>Net Total (PKR)</th>
                        <th>Audit Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($items)): ?>
                        <tr><td colspan="10" class="text-center text-muted py-4">Koi record nahi mila. Master workbook import karein.</td></tr>
                    <?php else: ?>
                        <?php foreach ($items as $it): ?>
                            <tr>
                                <td><span class="badge bg-primary"><?= $it['branch_code'] ?></span></td>
                                <td>
                                    <?php if ($it['audit_status'] === 'AUDITED_TARGET'): ?>
                                        <span class="badge bg-success">AUDITED TARGET</span>
                                    <?php elseif ($it['audit_status'] === 'PENDING_TARGET'): ?>
                                        <span class="badge bg-danger">PENDING</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">EXTRA ITEM</span>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-bold"><?= htmlspecialchars($it['item_code']) ?></td>
                                <td><small class="font-monospace text-muted"><?= htmlspecialchars($it['barcode'] ?: '-') ?></small></td>
                                <td><?= htmlspecialchars($it['item_description']) ?></td>
                                <td><small class="badge bg-light text-dark border"><?= htmlspecialchars($it['sub_group'] ?: '-') ?></small></td>
                                <td><?= number_format((float)$it['max_qty'], 1) ?></td>
                                <td class="fw-bold <?= (float)$it['total_adj_qty'] < 0 ? 'text-danger' : 'text-success' ?>">
                                    <?= $it['audit_status'] !== 'PENDING_TARGET' ? number_format((float)$it['total_adj_qty'], 1) : '-' ?>
                                </td>
                                <td class="fw-bold <?= (float)$it['total_net_value'] < 0 ? 'text-danger' : 'text-success' ?>">
                                    <?= $it['audit_status'] !== 'PENDING_TARGET' ? number_format((float)$it['total_net_value'], 2) : '-' ?>
                                </td>
                                <td><small class="text-muted"><?= !empty($it['audit_date']) ? date('d M, Y', strtotime($it['audit_date'])) : '-' ?></small></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>