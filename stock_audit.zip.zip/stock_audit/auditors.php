<?php
/**
 * Option 4: Auditor Transfers & CRUD Management
 * File: auditors.php
 */
declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';

$message = '';
$messageType = '';

// Handle Form Submissions (Create, Edit Target, Delete, Transfer)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 1. ADD NEW AUDITOR
    if ($action === 'create_auditor') {
        $name = trim($_POST['name'] ?? '');
        $code = trim($_POST['employee_code'] ?? '');
        $phone = trim($_POST['phone'] ?? '');

        if (!empty($name)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO auditors (name, employee_code, phone) VALUES (?, ?, ?)");
                $stmt->execute([$name, $code ?: null, $phone ?: null]);
                $message = "Auditor '{$name}' kamyabi se add ho gaya!";
                $messageType = "success";
            } catch (PDOException $e) {
                $message = "Error: " . $e->getMessage();
                $messageType = "danger";
            }
        }
    }

    // 2. TRANSFER AUDITOR (SCD TYPE 2 TEMPORAL LOGIC)
    if ($action === 'transfer_auditor') {
        $auditorId   = (int)($_POST['auditor_id'] ?? 0);
        $toBranch    = trim($_POST['to_branch'] ?? '');
        $dailyTarget = (int)($_POST['daily_target'] ?? 300);
        $targetDays  = (float)($_POST['target_days'] ?? 10);
        $startDate   = trim($_POST['effective_date'] ?? date('Y-m-d'));
        $remarks     = trim($_POST['remarks'] ?? '');

        if ($auditorId > 0 && !empty($toBranch) && !empty($startDate)) {
            try {
                $pdo->beginTransaction();

                // Step A: Close previous active assignment (end date is 1 day before effective date)
                $prevEnd = date('Y-m-d', strtotime($startDate . ' -1 day'));
                $closeStmt = $pdo->prepare("
                    UPDATE auditor_transfers 
                    SET end_date = ? 
                    WHERE auditor_id = ? AND end_date IS NULL
                ");
                $closeStmt->execute([$prevEnd, $auditorId]);

                // Step B: Insert new assignment
                $newStmt = $pdo->prepare("
                    INSERT INTO auditor_transfers 
                    (auditor_id, branch_code, daily_target_items, target_days, start_date, end_date, remarks) 
                    VALUES (?, ?, ?, ?, ?, NULL, ?)
                ");
                $newStmt->execute([$auditorId, $toBranch, $dailyTarget, $targetDays, $startDate, $remarks]);

                $pdo->commit();
                $message = "Auditor ko Branch [{$toBranch}] par successfully transfer kar diya gaya!";
                $messageType = "success";
            } catch (Exception $e) {
                $pdo->rollBack();
                $message = "Transfer error: " . $e->getMessage();
                $messageType = "danger";
            }
        }
    }

    // 3. EDIT DAILY TARGET
    if ($action === 'edit_target') {
        $transferId = (int)($_POST['transfer_id'] ?? 0);
        $newTarget  = (int)($_POST['daily_target'] ?? 300);

        if ($transferId > 0) {
            $pdo->prepare("UPDATE auditor_transfers SET daily_target_items = ? WHERE id = ?")->execute([$newTarget, $transferId]);
            $message = "Daily target update ho gaya!";
            $messageType = "success";
        }
    }

    // 4. DELETE AUDITOR
    if ($action === 'delete_auditor') {
        $auditorId = (int)($_POST['auditor_id'] ?? 0);
        if ($auditorId > 0) {
            $pdo->prepare("DELETE FROM auditors WHERE id = ?")->execute([$auditorId]);
            $message = "Auditor delete ho gaya.";
            $messageType = "warning";
        }
    }
}

// Fetch Active Auditors with current branch assignment
$auditors = $pdo->query("
    SELECT 
        a.id,
        a.name,
        a.employee_code,
        a.phone,
        t.id AS transfer_id,
        t.branch_code AS current_branch,
        t.daily_target_items,
        t.target_days,
        t.start_date AS assigned_since,
        b.name AS branch_name
    FROM auditors a
    LEFT JOIN auditor_transfers t ON a.id = t.auditor_id AND t.end_date IS NULL
    LEFT JOIN branches b ON t.branch_code = b.code
    ORDER BY a.name ASC
")->fetchAll();

// Fetch All Branches
$branches = $pdo->query("SELECT code, name FROM branches ORDER BY name ASC")->fetchAll();

// Fetch Complete Transfer History
$history = $pdo->query("
    SELECT 
        t.id,
        a.name AS auditor_name,
        t.branch_code,
        b.name AS branch_name,
        t.daily_target_items,
        t.target_days,
        t.start_date,
        t.end_date,
        t.remarks
    FROM auditor_transfers t
    INNER JOIN auditors a ON t.auditor_id = a.id
    LEFT JOIN branches b ON t.branch_code = b.code
    ORDER BY t.start_date DESC, t.id DESC
")->fetchAll();

$pageTitle = 'Option 4: Auditor Transfers & Management | Stock Audit Pro';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">Option 4: Auditor Transfers & Management</h3>
        <p class="text-muted m-0">Temporal date-range architecture: past audits stay linked to old branch, new audits link to transferred branch.</p>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-primary fw-bold" data-bs-toggle="modal" data-bs-target="#newAuditorModal">
            <i class="bi bi-person-plus me-1"></i> Add New Auditor
        </button>
        <button class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#transferModal">
            <i class="bi bi-arrow-left-right me-1"></i> Transfer Auditor
        </button>
    </div>
</div>

<?php if (!empty($message)): ?>
    <div class="alert alert-<?= $messageType ?> alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Active Deployments Table -->
<div class="card card-custom shadow-sm mb-4">
    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold"><i class="bi bi-person-badge text-primary me-2"></i> Current Active Auditor Deployments</h5>
        <span class="badge bg-success fs-6"><?= count($auditors) ?> Auditors</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Auditor Name</th>
                        <th>Emp Code</th>
                        <th>Phone</th>
                        <th>Current Branch</th>
                        <th>Daily Target</th>
                        <th>Active Since</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($auditors)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">Abhi koi auditor add nahi hua. "Add New Auditor" par click karein.</td></tr>
                    <?php else: ?>
                        <?php foreach ($auditors as $aud): ?>
                            <tr>
                                <td class="fw-bold text-dark"><?= htmlspecialchars($aud['name']) ?></td>
                                <td><?= htmlspecialchars($aud['employee_code'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($aud['phone'] ?? '-') ?></td>
                                <td>
                                    <?php if ($aud['current_branch']): ?>
                                        <span class="badge bg-primary fs-6"><?= $aud['current_branch'] ?></span>
                                        <small class="text-muted d-block"><?= htmlspecialchars($aud['branch_name'] ?? '') ?></small>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Unassigned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="fw-bold"><?= $aud['daily_target_items'] ?? 300 ?></span> items/day
                                    <?php if ($aud['transfer_id']): ?>
                                        <a href="javascript:void(0)" onclick="openEditTarget(<?= $aud['transfer_id'] ?>, <?= $aud['daily_target_items'] ?? 300 ?>)" class="text-primary ms-1 small"><i class="bi bi-pencil"></i></a>
                                    <?php endif; ?>
                                </td>
                                <td><?= $aud['assigned_since'] ? date('d M, Y', strtotime($aud['assigned_since'])) : '-' ?></td>
                                <td class="text-end">
                                    <button class="btn btn-sm btn-outline-primary me-1" onclick="openTransferFor(<?= $aud['id'] ?>)">
                                        <i class="bi bi-arrow-left-right"></i> Transfer
                                    </button>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Kya aap waqai is auditor ko delete karna chahte hain?');">
                                        <input type="hidden" name="action" value="delete_auditor">
                                        <input type="hidden" name="auditor_id" value="<?= $aud['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Historical Transfer Timeline -->
<div class="card card-custom shadow-sm">
    <div class="card-header bg-white py-3 border-bottom">
        <h5 class="m-0 fw-bold"><i class="bi bi-clock-history text-secondary me-2"></i> Complete Transfer History & Date Ranges</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered datatable">
                <thead class="table-dark">
                    <tr>
                        <th>Auditor</th>
                        <th>Branch</th>
                        <th>Daily Target</th>
                        <th>Target Days</th>
                        <th>Effective From</th>
                        <th>Effective To</th>
                        <th>Status</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($history as $h): ?>
                        <tr>
                            <td class="fw-bold"><?= htmlspecialchars($h['auditor_name']) ?></td>
                            <td><span class="badge bg-primary"><?= $h['branch_code'] ?></span> <?= htmlspecialchars($h['branch_name'] ?? '') ?></td>
                            <td><?= number_format((float)$h['daily_target_items']) ?> items/day</td>
                            <td><?= number_format((float)$h['target_days'], 1) ?> days</td>
                            <td><?= date('d M, Y', strtotime($h['start_date'])) ?></td>
                            <td><?= $h['end_date'] ? date('d M, Y', strtotime($h['end_date'])) : '<span class="badge bg-success">Current (Ongoing)</span>' ?></td>
                            <td>
                                <?= $h['end_date'] ? '<span class="badge bg-secondary">Past / Closed</span>' : '<span class="badge bg-success">Active</span>' ?>
                            </td>
                            <td><small class="text-muted"><?= htmlspecialchars($h['remarks'] ?? '-') ?></small></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal 1: Add Auditor -->
<div class="modal fade" id="newAuditorModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="create_auditor">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Add New Auditor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Auditor Full Name *</label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g. Asad Ullah">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Employee Code</label>
                        <input type="text" name="employee_code" class="form-control" placeholder="e.g. AUD-102">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="text" name="phone" class="form-control" placeholder="0300-0000000">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary fw-bold">Save Auditor</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal 2: Transfer Auditor -->
<div class="modal fade" id="transferModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="transfer_auditor">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Transfer / Assign Auditor to Branch</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Select Auditor *</label>
                        <select name="auditor_id" id="transferAuditorSelect" class="form-select" required>
                            <option value="">-- Choose Auditor --</option>
                            <?php foreach ($auditors as $a): ?>
                                <option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['name']) ?> (Current: <?= $a['current_branch'] ?: 'Unassigned' ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Target Branch (To Branch) *</label>
                        <select name="to_branch" class="form-select" required>
                            <option value="">-- Choose Branch --</option>
                            <?php foreach ($branches as $br): ?>
                                <option value="<?= $br['code'] ?>">[<?= $br['code'] ?>] <?= htmlspecialchars($br['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3"