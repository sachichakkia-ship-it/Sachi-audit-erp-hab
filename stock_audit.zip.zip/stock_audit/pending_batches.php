<?php
/**
 * Option 3: Sub-Group-Wise 300-Item Pending Batches
 * File: pending_batches.php
 */
declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/constants.php';

$pageTitle = '300-Item Pending Batches | Stock Audit Pro';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Filter inputs
$filterBranch   = trim($_GET['branch'] ?? 'EME'); // Default to EME
$filterSubGroup = trim($_GET['sub_group'] ?? '');
$selectedBatch  = (int)($_GET['batch_no'] ?? 1); // Default to Batch 1

// 1. Fetch Branches for dropdown
$branches = $pdo->query("SELECT code, name FROM branches ORDER BY name ASC")->fetchAll();

// 2. Fetch distinct Sub Groups for the selected branch
$subGroupStmt = $pdo->prepare("
    SELECT DISTINCT sub_group 
    FROM target_items 
    WHERE branch_code = ? AND sub_group IS NOT NULL AND sub_group != ''
    ORDER BY sub_group ASC
");
$subGroupStmt->execute([$filterBranch]);
$subGroups = $subGroupStmt->fetchAll(PDO::FETCH_COLUMN);

// 3. Fetch ONLY Pending Target Items (Not yet audited in adjustments for this branch)
// This query dynamically excludes any item that has been audited in view_deduplicated_audits
$whereSubGroup = !empty($filterSubGroup) ? "AND t.sub_group = :sub_group" : "";

$pendingQuery = "
    SELECT 
        t.id,
        t.branch_code,
        t.group_name,
        t.sub_group,
        t.item_code,
        t.barcode,
        t.item_description,
        t.max_qty,
        t.oct_sale
    FROM target_items t
    LEFT JOIN view_deduplicated_audits v 
        ON t.branch_code = v.branch_code 
        AND t.item_code = v.item_code
    WHERE t.branch_code = :branch
      AND v.item_code IS NULL
      {$whereSubGroup}
    ORDER BY t.sub_group ASC, t.item_code ASC
";

$pendingStmt = $pdo->prepare($pendingQuery);
$params = [':branch' => $filterBranch];
if (!empty($filterSubGroup)) {
    $params[':sub_group'] = $filterSubGroup;
}
$pendingStmt->execute($params);
$allPendingItems = $pendingStmt->fetchAll();

// 4. Batch Calculation (Chunk items into groups of 300)
$batchSize = 300;
$totalPendingCount = count($allPendingItems);
$totalBatches = (int)ceil($totalPendingCount / $batchSize);

if ($selectedBatch < 1) $selectedBatch = 1;
if ($selectedBatch > $totalBatches && $totalBatches > 0) $selectedBatch = $totalBatches;

$offset = ($selectedBatch - 1) * $batchSize;
$currentBatchItems = array_slice($allPendingItems, $offset, $batchSize);

$startSerial = $totalPendingCount > 0 ? $offset + 1 : 0;
$endSerial   = min($offset + $batchSize, $totalPendingCount);

// Export batch query URL
$exportBatchQuery = http_build_query([
    'type'      => 'pending_batch',
    'branch'    => $filterBranch,
    'sub_group' => $filterSubGroup,
    'batch_no'  => $selectedBatch
]);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">Option 3: Sub-Group-Wise 300-Item Batches</h3>
        <p class="text-muted m-0">Sequential 300-item physical sheets. Audited items automatically disappear from batches.</p>
    </div>
    <?php if (!empty($currentBatchItems)): ?>
        <a href="actions/export_excel.php?<?= $exportBatchQuery ?>" class="btn btn-success fw-bold shadow-sm">
            <i class="bi bi-file-earmark-excel me-1"></i> Export Batch #<?= $selectedBatch ?> to Excel
        </a>
    <?php endif; ?>
</div>

<!-- Filters Card -->
<div class="card card-custom p-3 mb-4 shadow-sm">
    <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-4">
            <label class="form-label fw-bold small text-muted">Select Branch *</label>
            <select name="branch" class="form-select" onchange="this.form.submit()">
                <?php foreach ($branches as $br): ?>
                    <option value="<?= $br['code'] ?>" <?= $filterBranch === $br['code'] ? 'selected' : '' ?>>
                        [<?= $br['code'] ?>] <?= htmlspecialchars($br['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-5">
            <label class="form-label fw-bold small text-muted">Filter by Sub Group (Optional):</label>
            <select name="sub_group" class="form-select" onchange="this.form.submit()">
                <option value="">-- All Sub Groups (Combined) --</option>
                <?php foreach ($subGroups as $sg): ?>
                    <option value="<?= htmlspecialchars($sg) ?>" <?= $filterSubGroup === $sg ? 'selected' : '' ?>>
                        <?= htmlspecialchars($sg) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-primary w-100 fw-bold">
                <i class="bi bi-funnel me-1"></i> Load Batches
            </button>
            <a href="pending_batches.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-counterclockwise"></i>
            </a>
        </div>
    </form>
</div>

<!-- Batch Statistics Bar -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card card-custom p-3 border-start border-danger border-4 shadow-sm">
            <span class="text-muted small fw-bold text-uppercase">Total Pending Target Items</span>
            <h4 class="fw-bold text-danger m-0 mt-1"><?= number_format($totalPendingCount) ?> Items</h4>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-custom p-3 border-start border-primary border-4 shadow-sm">
            <span class="text-muted small fw-bold text-uppercase">Total Batches (300 Items Each)</span>
            <h4 class="fw-bold text-primary m-0 mt-1"><?= number_format($totalBatches) ?> Batches</h4>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-custom p-3 border-start border-success border-4 shadow-sm">
            <span class="text-muted small fw-bold text-uppercase">Active Viewing Range</span>
            <h4 class="fw-bold text-success m-0 mt-1">Items <?= $startSerial ?> &ndash; <?= $endSerial ?></h4>
        </div>
    </div>
</div>

<!-- Batch Selection Tabs / Badges -->
<?php if ($totalBatches > 1): ?>
    <div class="card card-custom p-3 mb-4 shadow-sm">
        <label class="fw-bold small text-muted mb-2">Select Batch Sheet to View / Print:</label>
        <div class="d-flex flex-wrap gap-2">
            <?php for ($b = 1; $b <= $totalBatches; $b++): ?>
                <?php 
                    $bStart = ($b - 1) * 300 + 1;
                    $bEnd   = min($b * 300, $totalPendingCount);
                    $url = "pending_batches.php?" . http_build_query([
                        'branch'    => $filterBranch,
                        'sub_group' => $filterSubGroup,
                        'batch_no'  => $b
                    ]);
                ?>
                <a href="<?= $url ?>" class="btn btn-sm <?= $selectedBatch === $b ? 'btn-primary fw-bold' : 'btn-outline-secondary' ?>">
                    Batch <?= $b ?> <span class="badge bg-light text-dark ms-1"><?= $bStart ?>-<?= $bEnd ?></span>
                </a>
            <?php endfor; ?>
        </div>
    </div>
<?php endif; ?>

<!-- Batch Items Table -->
<div class="card card-custom shadow-sm">
    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">
            <i class="bi bi-card-checklist text-primary me-2"></i>
            Batch #<?= $selectedBatch ?> Sheet (Branch: [<?= $filterBranch ?>] &bull; Showing <?= count($currentBatchItems) ?> of 300 items)
        </h5>
        <span class="badge bg-danger fs-6">Pending Physical Scans</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th style="width: 60px;">#</th>
                        <th>Sub Group</th>
                        <th>Item Code</th>
                        <th>Barcode</th>
                        <th>Item Description</th>
                        <th>Max Qty</th>
                        <th>Oct Sale</th>
                        <th style="width: 140px;" class="text-center bg-secondary">Auditor Physical Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($currentBatchItems)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-5">SubhanAllah! Is branch ya sub-group mein koi pending item nahi hai (ya abhi master sheet import nahi hui).</td></tr>
                    <?php else: ?>
                        <?php 
                        $serial = $startSerial;
                        foreach ($currentBatchItems as $item): 
                        ?>
                            <tr>
                                <td class="text-center fw-bold text-muted"><?= $serial++ ?></td>
                                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($item['sub_group'] ?: '-') ?></span></td>
                                <td class="fw-bold text-primary font-monospace"><?= htmlspecialchars($item['item_code']) ?></td>
                                <td class="font-monospace text-muted small"><?= htmlspecialchars($item['barcode'] ?: '-') ?></td>
                                <td><?= htmlspecialchars($item['item_description']) ?></td>
                                <td><?= number_format((float)$item['max_qty'], 1) ?></td>
                                <td><?= number_format((float)$item['oct_sale'], 1) ?></td>
                                <td class="bg-light text-center" style="border-left: 2px dashed #cbd5e1;">
                                    <!-- Print space for physical counting -->
                                    <span class="text-muted" style="font-size: 11px;">[ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ]</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>